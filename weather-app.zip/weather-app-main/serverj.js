
const express = require('express')
const bodyParser = require('body-parser')
const https = require('https')

const app = express()
app.use(bodyParser.urlencoded({extended: true}))

const port = 3000

app.listen(port, ()=>{
    console.log(`Server is running on port ${port}`)
})

app.get('/', (req, res)=>{
    const city = "Bangkok";

    const url = "https://api.openweathermap.org/data/2.5/weather?q=" +city+ "&appid=d024c40d45b6fd062a80c784e3ce18ef&units=metric"

    https.get(url, (response)=>{
        console.log(response);

        response.on("data", (data)=>{
            //console.log(data);
            const weatherData = JSON.parse(data);
            // console.log(weatherData);
            const temp = weatherData.main.temp;
            // console.log(temp);
            // res.send(`The temperature is ${temp}`);
            const description = weatherData.weather[0].description
            const icon = weatherData.weather[0].icon
            const iconURL = "https://openweathermap.org/img/wn/" + icon + "@2x.png"


            res.write(`<h1> The weather in ${city} is ${description}`)
            res.write(`<h1> The temperature in ${city} is ${temp} degree celcius`)
            res.write(`<img src = ${iconURL}>`)
        })

    })

})
